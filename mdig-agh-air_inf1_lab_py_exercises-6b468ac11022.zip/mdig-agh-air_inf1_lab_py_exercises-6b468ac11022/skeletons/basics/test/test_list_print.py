from basics import list_print

list_print()

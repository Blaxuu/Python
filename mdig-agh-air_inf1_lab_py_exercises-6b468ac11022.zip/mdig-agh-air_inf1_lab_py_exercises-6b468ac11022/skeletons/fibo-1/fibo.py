# TODO: Dodaj takie importy, aby poniższe instrukcje były poprawne

print(recursive.fib(3))
print(fib(3))
print(PI)

from typing import TypeVar, Container


class Movable:
    # TODO: zaimplementuj...
    pass


class Vehicle:
    # TODO: zaimplementuj...
    pass


# TODO: Zmień wywołanie TypeVar() tak, aby 'V' był podtypem klasy 'Vehicle' (zob. parametr 'bound').
V = TypeVar('V')


def vehicle_collection_as_string(vehicles: Container[V]) -> str:
    raise NotImplementedError


class Car:
    # TODO: zaimplementuj...
    pass


class Bicycle:
    # TODO: zaimplementuj...
    pass


def compute_min_travel_duration(distance: float, vehicle: Vehicle) -> float:
    raise NotImplementedError


def compute_min_travel_duration_as_string(distance: float, vehicle: Vehicle) -> str:
    raise NotImplementedError

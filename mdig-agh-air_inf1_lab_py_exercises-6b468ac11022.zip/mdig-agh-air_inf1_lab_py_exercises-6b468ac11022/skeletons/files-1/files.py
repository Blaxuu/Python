def write_to_file(path: str) -> bool:
    raise NotImplementedError

class Product:
    # TODO: zaimplementuj...

    def __str__(self) -> str:
        raise NotImplementedError

    def __eq__(self, other) -> bool:
        raise NotImplementedError


class Catalogue:
    # TODO: zaimplementuj...

    def __contains__(self, id_: str) -> bool:
        raise NotImplementedError
